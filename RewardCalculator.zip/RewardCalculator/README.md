Reward Point

Build the project with below commad
mvn clean install

Run the code
mvn spring-boot:run

Rest API detail

1. Get Reward by Customer Id
Method : Get
http://localhost:8080/rewardsPoint/customers/1001

2. Get Customer By Id

Method : Get
http://localhost:8080/customers/1001

3. Get Transaction By Id
Method : Get

http://localhost:8080/rewardsPoint/customers/1001


