package com.rewards.rewardcalculater.constants;

public class Constants {
    public static final int daysInMonth = 30;
    public static int firstReward = 50;
    public static int secondReward = 100;
}
